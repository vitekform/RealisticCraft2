package cz.vitekform.rc2.blocks.blockentities;

import cz.vitekform.rc2.ModBlockEntities;
import cz.vitekform.rc2.classes.ElectricDevice;
import cz.vitekform.rc2.classes.ElectricTransfer;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5558;

public class GeneratorBlockEntity extends class_2586 implements ElectricDevice, class_5558<GeneratorBlockEntity> {
    private double storedEnergy = 0.0;

    public GeneratorBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.GENERATOR_BLOCK_ENTITY, pos, state);
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state, GeneratorBlockEntity blockEntity) {
        if (!world.field_9236) {
            double generatedPower = getVoltage() * getAmperage(); // W = V × A
            storedEnergy = Math.min(getMaxEnergy(), storedEnergy + generatedPower);

            ElectricTransfer out = extractPower(getVoltage(), getAmperage());

            for (class_2350 dir : class_2350.values()) {
                class_2586 neighbor = world.method_8321(pos.method_10093(dir));
                if (neighbor instanceof ElectricDevice device) {
                    if (device.getVoltage() == getVoltage()) {
                        device.receivePower(out);
                    }
                }
            }
        }
    }

    @Override public double getVoltage() { return 32.0; }
    @Override public double getAmperage() { return 1.0; }
    @Override public double getStoredEnergy() { return storedEnergy; }
    @Override public double getMaxEnergy() { return 10_000.0; }

    @Override
    public void receivePower(ElectricTransfer transfer) {
        // generators don’t accept power
    }

    @Override
    public ElectricTransfer extractPower(double maxVoltage, double maxAmperage) {
        if (maxVoltage < getVoltage()) return new ElectricTransfer(0, 0);

        double potentialPower = Math.min(storedEnergy, getVoltage() * maxAmperage);
        double actualAmperage = potentialPower / getVoltage();

        storedEnergy -= potentialPower;
        return new ElectricTransfer(getVoltage(), actualAmperage);
    }
}
