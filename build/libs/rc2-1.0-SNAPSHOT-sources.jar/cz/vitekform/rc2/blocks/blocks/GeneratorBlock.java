package cz.vitekform.rc2.blocks.blocks;

import cz.vitekform.rc2.blocks.blockentities.GeneratorBlockEntity;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.Nullable;
import cz.vitekform.rc2.ModBlockEntities;

public class GeneratorBlock extends class_2237 {
    public static final MapCodec<GeneratorBlock> CODEC = method_54094(GeneratorBlock::new);

    public GeneratorBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GeneratorBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.GENERATOR_BLOCK_ENTITY,
                (world1, pos, state1, be) -> ((GeneratorBlockEntity) be).tick(world1, pos, state1, (GeneratorBlockEntity) be));
    }
}