package cz.vitekform.rc2.blocks.blocks;

import com.mojang.serialization.MapCodec;
import cz.vitekform.rc2.blocks.blockentities.BatteryBlockEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class BatteryBlock extends class_2237 {
    public static final MapCodec<BatteryBlock> CODEC = method_54094(BatteryBlock::new);

    public BatteryBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new BatteryBlockEntity(pos, state);
    }

    @Override
    public class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        //if (!world.isClient) {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof BatteryBlockEntity battery) {
                String energyInfo = String.format("Stored Energy: %.2f W (%.1f%%)",
                        battery.getStoredEnergy(),
                        (battery.getStoredEnergy() / battery.getMaxEnergy()) * 100);
                player.method_7353(class_2561.method_43470(energyInfo), false);
            }
            else {
                player.method_7353(class_2561.method_43470("Error - blockEntity not BatteryBlockEntity!"), false);
            }
        //}
        //else {
        //    player.sendMessage(Text.literal("Error - world is client!"), false);
        //}
        return class_1269.field_5812;
    }
}