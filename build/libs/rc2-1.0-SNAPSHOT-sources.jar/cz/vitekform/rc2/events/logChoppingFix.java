package cz.vitekform.rc2.events;

import cz.vitekform.rc2.ModItems;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.logging.Logger;

/*
What this does:
When you mine log without an axe you don't get the block, but the block is still mined.
When you mine log with axe it strips it and drops bark.
When you mine stripped log with axe it changes itselfs to planks.
 */
public class logChoppingFix {
    public static void init() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, blockPos, blockState, blockEntity) -> {
            if (blockState.method_26204().method_9539().contains("log") && !(blockState.method_26204().method_9539().contains("stripped"))) {
                if (player.method_5998(player.method_6058()).method_7909().method_7876().contains("axe") || player.method_5998(player.method_6058()).method_7909() == ModItems.SHARP_ROCK_ITEM.method_8389()) {
                    String blockName = blockState.method_26204().method_9539();
                    String[] parts = blockName.split("\\.");
                    String strippedBlockName = "";
                    for (int i = 0; i < parts.length; i++) {
                        if (i == parts.length - 1) {
                            strippedBlockName += "stripped_";
                        }
                        strippedBlockName += parts[i];
                        if (i != parts.length - 1) {
                            strippedBlockName += ".";
                        }
                    }
                    // Get the stripped log block state from its translation key
                    strippedBlockName = strippedBlockName.replace("block.minecraft.", "minecraft:");
                    class_2680 newBState = class_7923.field_41175.method_10223(class_2960.method_60654(strippedBlockName)).method_9564();
                    // Set the block to stripped log
                    world.method_8501(blockPos, newBState);
                    player.method_5998(player.method_6058()).method_7970(1, player, class_1309.method_56079(player.method_6058()));
                    // Drop bark
                    world.method_8649(new class_1542(world, blockPos.method_10263(), blockPos.method_10264() + 0.5, blockPos.method_10260(), ModItems.WOOD_BARK.method_7854()));
                    if (player.method_5998(player.method_6058()).method_7909() == ModItems.SHARP_ROCK_ITEM.method_8389()) {
                        player.method_5998(player.method_6058()).method_7934(1);
                    }
                    return false;
                }
                else {
                    return false;
                }
            }
            else if (blockState.method_26204().method_9539().contains("stripped") && blockState.method_26204().method_9539().contains("log")) {
                if (player.method_5998(player.method_6058()).method_7909().method_7876().contains("axe")) {
                    // Get the planks block state from its translation key
                    String blockName = blockState.method_26204().method_9539();
                    String ps = blockName.split("stripped_")[1];
                    ps = ps.split("_log")[0];
                    String planksBlockName = "minecraft:" + ps + "_planks";
                    Logger.getGlobal().info(planksBlockName);
                    class_2680 newBState = class_7923.field_41175.method_10223(class_2960.method_60654(planksBlockName)).method_9564();
                    player.method_5998(player.method_6058()).method_7970(1, player, class_1309.method_56079(player.method_6058()));
                    // Set the block to planks
                    world.method_8501(blockPos, newBState);
                    return false;
                }
                else {
                    return false;
                }
            }
            return true;
        });
    }
}