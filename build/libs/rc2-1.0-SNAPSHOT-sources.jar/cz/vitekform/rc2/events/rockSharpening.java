package cz.vitekform.rc2.events;

import cz.vitekform.rc2.ModItems;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_3417;
import java.util.Random;

public class rockSharpening {

    public static void init() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, entity) -> {
            boolean canHarvestBlock = player.method_5998(player.method_6058()).method_7951(state);
            boolean isRock = state.method_26204() == class_2246.field_10340 || state.method_26204() == class_2246.field_10474 || state.method_26204() == class_2246.field_10508 || state.method_26204() == class_2246.field_10115 || state.method_26204() == class_2246.field_10445 || state.method_26204() == class_2246.field_28888 || state.method_26204() == class_2246.field_27165 || state.method_26204() == class_2246.field_22091 || state.method_26204() == class_2246.field_23869 || state.method_26204() == class_2246.field_29031;
            if (!canHarvestBlock && isRock) {
                class_1799 rocks = new class_1799(ModItems.ROCK_ITEM);
                int amount = new Random().nextInt(1, 5);
                rocks.method_7939(amount);
                world.method_8649(new class_1542(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), rocks));
                return true;
            }
            return true;
        });


        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            class_2248 block = world.method_8320(hitResult.method_17777()).method_26204();
            if (player.method_5998(hand).method_7909() == ModItems.ROCK_ITEM && block.method_36555() >= 1.5f) {
                if (new Random().nextInt(1, 6) == 5) {
                    player.method_5783(class_3417.field_15075, 1.0F, 1.0F);
                    player.method_5998(hand).method_7934(1);
                    world.method_8649(new class_1542(world, hitResult.method_17777().method_10263(), hitResult.method_17777().method_10264(), hitResult.method_17777().method_10260(), new class_1799(ModItems.SHARP_ROCK_ITEM)));
                    return class_1269.field_5812;
                }
                else {
                    player.method_5783(class_3417.field_15026, 1.0F, 1.0F);
                    player.method_5998(hand).method_7934(1);
                    return class_1269.field_5812;
                }
            }
            return class_1269.field_5811;
        });
    }
}
