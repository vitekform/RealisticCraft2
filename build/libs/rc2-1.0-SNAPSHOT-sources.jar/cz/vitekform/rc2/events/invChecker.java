package cz.vitekform.rc2.events;

import cz.vitekform.rc2.ModItems;
import cz.vitekform.rc2.internal.PlayerInventoryClickCallback;
import net.minecraft.class_1269;

public class invChecker {

    public static void init() {
        PlayerInventoryClickCallback.EVENT.register((player, clickType, slot, itemStack, cursorStack, screenHandler) -> {
            ModItems.processItemTags(itemStack);
            ModItems.processItemTags(cursorStack);
            return class_1269.field_5811;
        });
    }
}
