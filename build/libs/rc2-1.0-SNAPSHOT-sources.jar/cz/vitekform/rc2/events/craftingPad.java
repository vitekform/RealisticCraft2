package cz.vitekform.rc2.events;

import cz.vitekform.rc2.ModBlocks;
import cz.vitekform.rc2.internal.cutils.crafting_pad.CP_ScreenHandler;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_2561;
import net.minecraft.class_747;

public class craftingPad {

    public static void init() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8320(hitResult.method_17777()).method_26204() == ModBlocks.CRAFTING_PAD) {
                player.method_17355(new class_747(
                        (syncId, inv, p) -> new CP_ScreenHandler(syncId, inv, hitResult.method_17777()),
                        class_2561.method_43470("Crafting Pad")
                ));
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        });
    }
}
