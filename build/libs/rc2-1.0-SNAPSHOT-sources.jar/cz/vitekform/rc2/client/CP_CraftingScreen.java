package cz.vitekform.rc2.client;

import cz.vitekform.rc2.internal.cutils.crafting_pad.CP_ScreenHandler;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class CP_CraftingScreen extends class_465<CP_ScreenHandler> {
    private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/gui/container/crafting_table.png");

    public CP_CraftingScreen(CP_ScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        context.method_25302(TEXTURE, (field_22789 - field_2792) / 2, (field_22790 - field_2779) / 2, 0, 0, field_2792, field_2779);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        field_25267 = (field_2792 - field_22793.method_27525(field_22785)) / 2;
    }
}