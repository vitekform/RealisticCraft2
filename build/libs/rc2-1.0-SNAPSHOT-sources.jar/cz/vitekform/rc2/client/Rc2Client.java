package cz.vitekform.rc2.client;

import cz.vitekform.rc2.internal.cutils.crafting_pad.CP_ScreenHandlers;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;

public class Rc2Client implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_3929.method_17542(CP_ScreenHandlers.PEBBLE_CRAFTING_SCREEN_HANDLER, CP_CraftingScreen::new);
    }
}