package cz.vitekform.rc2;

import cz.vitekform.rc2.blocks.blockentities.BatteryBlockEntity;
import cz.vitekform.rc2.blocks.blockentities.CableBlockEntity;
import cz.vitekform.rc2.blocks.blockentities.GeneratorBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities {
    public static class_2591<GeneratorBlockEntity> GENERATOR_BLOCK_ENTITY;
    public static class_2591<BatteryBlockEntity> BATTERY_BLOCK_ENTITY;
    public static class_2591<CableBlockEntity> CABLE_BLOCK_ENTITY;

    public static void registerAllBlockEntities() {
        GENERATOR_BLOCK_ENTITY = class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655(Rc2.MOD_ID, "generator"),
                FabricBlockEntityTypeBuilder.create(GeneratorBlockEntity::new, ModBlocks.GENERATOR_BLOCK_DEV).build(null)
        );

        BATTERY_BLOCK_ENTITY = class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655(Rc2.MOD_ID, "battery"),
                FabricBlockEntityTypeBuilder.create(BatteryBlockEntity::new, ModBlocks.BATTERY_BLOCK_DEV).build(null)
        );

        CABLE_BLOCK_ENTITY = class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655(Rc2.MOD_ID, "cable"),
                FabricBlockEntityTypeBuilder.create(CableBlockEntity::new, ModBlocks.CABLE_BLOCK_DEV).build(null)
        );
    }
}
