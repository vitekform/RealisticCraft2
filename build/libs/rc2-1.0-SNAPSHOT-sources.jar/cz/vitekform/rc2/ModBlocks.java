package cz.vitekform.rc2;

import cz.vitekform.rc2.energy.blocks.blocks.BatteryBlock;
import cz.vitekform.rc2.energy.blocks.blocks.CableBlock;
import cz.vitekform.rc2.energy.blocks.blocks.GeneratorBlock;
import cz.vitekform.rc2.internal.blocks.CraftingPadBlock;
import java.util.logging.Logger;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModBlocks {

    public static class_2248 register(class_2248 block, class_5321<class_2248> blockKey, boolean shouldRegisterItem) {
        // Sometimes, you may not want to register an item for the block.
        // Eg: if it's a technical block like `minecraft:air` or `minecraft:end_gateway`
        if (shouldRegisterItem) {
            // Items need to be registered with a different type of registry key, but the ID
            // can be the same.
            class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, blockKey.method_29177());

            class_1747 blockItem = new class_1747(block, new class_1792.class_1793());
            class_2378.method_39197(class_7923.field_41178, itemKey, blockItem);
        }
        return class_2378.method_39197(class_7923.field_41175, blockKey, block);
    }

    public static final class_5321<class_2248> CRAFTING_PAD_KEY = class_5321.method_29179(
            class_7924.field_41254,
            class_2960.method_60655("rc2", "crafting_pad")
    );

    public static final class_5321<class_2248> GENERATOR_BLOCK_KEY = class_5321.method_29179(
            class_7924.field_41254,
            class_2960.method_60655("rc2", "generator_dev")
    );

    public static final class_5321<class_2248> BATTERY_BLOCK_KEY = class_5321.method_29179(
            class_7924.field_41254,
            class_2960.method_60655("rc2", "battery_dev")
    );

    public static final class_5321<class_2248> CABLE_BLOCK_KEY = class_5321.method_29179(
            class_7924.field_41254,
            class_2960.method_60655("rc2", "cable_dev")
    );

    public static final class_2248 CRAFTING_PAD = register(
            new CraftingPadBlock(class_2248.Settings.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_42327()
                    .method_36557(2)
                    .method_9629(1.0f, 3.0f)),
            CRAFTING_PAD_KEY,
            true
    );

    public static final class_2248 GENERATOR_BLOCK_DEV = register(
            new GeneratorBlock(class_2248.Settings.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_42327()
                    .method_36557(2)
                    .method_9629(1.0f, 3.0f)),
            GENERATOR_BLOCK_KEY,
            true
    );

    public static final class_2248 BATTERY_BLOCK_DEV = register(
            new BatteryBlock(class_2248.Settings.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_42327()
                    .method_36557(2)
                    .method_9629(1.0f, 3.0f)),
            BATTERY_BLOCK_KEY,
            true
    );

    public static final class_2248 CABLE_BLOCK_DEV = register(
            new CableBlock(class_2248.Settings.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_42327()
                    .method_36557(2)
                    .method_9629(1.0f, 3.0f)),
            CABLE_BLOCK_KEY,
            true
    );

    public static void init() {
        if (CRAFTING_PAD == null) {
            Logger.getLogger("rc2").warning("Failed to initialize Crafting Pad block.");
        }
    }
}
