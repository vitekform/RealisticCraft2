package cz.vitekform.rc2.energy.blocks.blockentities;

import cz.vitekform.rc2.ModBlockEntities;
import cz.vitekform.rc2.classes.ElectricDevice;
import cz.vitekform.rc2.classes.ElectricTransfer;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5558;

public class CableBlockEntity extends class_2586 implements class_5558<CableBlockEntity> {
    public static final double MAX_AMPS = 8.0;
    public static final double VOLTAGE_DROP = 0.5; // simulate resistance

    public CableBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CABLE_BLOCK_ENTITY, pos, state);
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state, CableBlockEntity blockEntity) {
        if (world.field_9236) return;

        // Find power sources and consumers in adjacent blocks
        for (class_2350 sourceDir : class_2350.values()) {
            class_2586 sourceEntity = world.method_8321(pos.method_10093(sourceDir));
            if (!(sourceEntity instanceof ElectricDevice source)) continue;

            // Extract power from the source
            ElectricTransfer power = source.extractPower(Double.MAX_VALUE, MAX_AMPS);
            if (power.amperage() <= 0) continue;

            // Apply voltage drop due to cable resistance
            double transferVoltage = Math.max(0, power.voltage() - VOLTAGE_DROP);
            ElectricTransfer modifiedPower = new ElectricTransfer(transferVoltage, power.amperage());

            // Try to distribute power to other adjacent blocks
            for (class_2350 targetDir : class_2350.values()) {
                if (targetDir == sourceDir.method_10153()) continue; // Skip the source direction

                class_2586 targetEntity = world.method_8321(pos.method_10093(targetDir));
                if (targetEntity instanceof ElectricDevice target) {
                    target.receivePower(modifiedPower);
                    break; // Transfer to only one consumer per source
                }
            }
        }
    }
}