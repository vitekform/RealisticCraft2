package cz.vitekform.rc2;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_2447;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class Rc2RecipeProvider extends FabricRecipeProvider {
    public Rc2RecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    public void method_10419(class_8790 recipeExporter) {
        class_2447.method_10437(class_7800.field_40638, class_1802.field_8062)
                .method_10434('S', class_1802.field_8600)
                .method_10434('R', ModItems.SHARP_ROCK_ITEM)
                .method_10439("RR")
                .method_10439("RS")
                .method_10439(" S")
                .method_10429(method_32807(ModItems.SHARP_ROCK_ITEM), method_10426(ModItems.SHARP_ROCK_ITEM))
                .method_10431(recipeExporter);

        class_2447.method_10437(class_7800.field_40638, class_1802.field_8387)
                .method_10434('S', class_1802.field_8600)
                .method_10434('R', ModItems.SHARP_ROCK_ITEM)
                .method_10439("RRR")
                .method_10439(" S ")
                .method_10439(" S ")
                .method_10429(method_32807(ModItems.SHARP_ROCK_ITEM), method_10426(ModItems.SHARP_ROCK_ITEM))
                .method_10431(recipeExporter);
    }


    @Override
    public String method_10321() {
        return "FabricDocsReferenceRecipeProvider";
    }
}
