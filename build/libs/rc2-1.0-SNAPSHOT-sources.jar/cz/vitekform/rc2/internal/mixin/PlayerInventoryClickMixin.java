package cz.vitekform.rc2.internal.mixin;

import cz.vitekform.rc2.internal.PlayerInventoryClickCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1703.class)
public class PlayerInventoryClickMixin {
    @Inject(
            method = "handleSlotClick",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onInventoryClick(
            class_1657 player, net.minecraft.class_5536 clickType, class_1735 slot, class_1799 stack, class_1799 cursorStack, CallbackInfoReturnable<Boolean> cir
    ) {
        class_1269 result = PlayerInventoryClickCallback.EVENT.invoker().interact(
                player,
                clickType,
                slot,
                stack,
                cursorStack,
                (class_1703) (Object) this
        );

        if (result == class_1269.field_5814) {
            cir.setReturnValue(false);
            cir.cancel();
        }
    }
}