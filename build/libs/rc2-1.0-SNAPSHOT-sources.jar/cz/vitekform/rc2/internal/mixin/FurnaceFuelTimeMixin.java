package cz.vitekform.rc2.internal.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2609;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2609.class)
public class FurnaceFuelTimeMixin {
    @Inject(method = "getFuelTime", at = @At("RETURN"), cancellable = true)
    private void modifyFuelTime(class_1799 fuel, CallbackInfoReturnable<Integer> cir) {
        class_2609 furnace = (class_2609) (Object) this;
        class_1799 smeltingItem = furnace.method_5438(0);

        /*if (!smeltingItem.isEmpty()) {
            int baseBurnTime = cir.getReturnValue();
            double modifier = calculateModifier(smeltingItem);
            cir.setReturnValue((int)(baseBurnTime * modifier));
        }*/
    }

    private static double calculateModifier(class_1799 smeltingItem) {
        if (smeltingItem.method_31574(class_1802.field_8599)) {
            return 0.1; // It will take 10 times more fuel to smelt iron ore
        }
        return 1.0;
    }
}