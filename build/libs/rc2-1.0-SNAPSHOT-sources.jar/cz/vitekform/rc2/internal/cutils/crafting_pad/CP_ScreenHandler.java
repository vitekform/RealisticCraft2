package cz.vitekform.rc2.internal.cutils.crafting_pad;

import cz.vitekform.rc2.ModBlocks;
import cz.vitekform.rc2.ModComponents;
import cz.vitekform.rc2.ModItems;
import cz.vitekform.rc2.internal.blocks.CraftingPadBlock;
import cz.vitekform.rc2.internal.cutils.crafting_pad.CP_ScreenHandlers;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1715;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2645;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.class_3955;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import net.minecraft.screen.*;
import org.apache.commons.logging.Log;

import java.util.Collection;
import java.util.Optional;
import java.util.logging.Logger;

public class CP_ScreenHandler extends class_1703 {
    private final class_1715 craftingInventory;
    private final class_1263 resultInventory;
    private final class_3913 propertyDelegate;
    private final class_1937 world;
    private class_2338 bpos;

    public CP_ScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, new class_1277(10), new class_3919(1));
    }

    public CP_ScreenHandler(int syncId, class_1661 playerInventory, class_2338 bpos) {
        this(syncId, playerInventory, new class_1277(10), new class_3919(1));
        this.bpos = bpos;
    }

    public CP_ScreenHandler(int syncId, class_1661 playerInventory, class_1263 inventory, class_3913 propertyDelegate) {
        super(CP_ScreenHandlers.PEBBLE_CRAFTING_SCREEN_HANDLER, syncId);
        this.craftingInventory = new class_1715(this, 3, 3);
        this.resultInventory = new class_1277(1); // Only one slot for result
        this.propertyDelegate = propertyDelegate;
        this.world = playerInventory.field_7546.method_37908();

        // Add crafting grid slots (3x3)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                this.method_7621(new class_1735(craftingInventory, col + row * 3, 30 + col * 18, 17 + row * 18));
            }
        }

        // Add result slot
        this.method_7621(new class_1734(playerInventory.field_7546, craftingInventory, resultInventory, 0, 124, 35) {
            @Override
            public void method_7667(class_1657 player, class_1799 stack) {
                // Consume the ingredients
                for (int i = 0; i < 9; i++) {
                    class_1799 ingredient = craftingInventory.method_5438(i);
                    if (!ingredient.method_7960()) {
                        ingredient.method_7934(1);
                    }
                }

                if (bpos != null) {
                    class_2680 state = world.method_8320(bpos);
                    int used_times;
                    if (state.method_28498(CraftingPadBlock.UsedTimes)) {
                        used_times = state.method_11654(CraftingPadBlock.UsedTimes);
                    }
                    else {
                        used_times = 0;
                    }
                    used_times++;
                    if (used_times >= 5) {
                        world.method_8501(bpos, class_7923.field_41175.method_10223(class_2960.method_60654("minecraft:air")).method_9564());
                        world.method_8486(bpos.method_10263(), bpos.method_10264(), bpos.method_10260(), class_3417.field_15026, class_3419.field_15245, 2.0f, 1.0f, false);
                        class_3222 playerEntity = (class_3222) player;
                        class_2645 packet = new class_2645(playerEntity.field_7512.field_7763);
                        playerEntity.field_13987.method_14364(packet);
                    }
                    else {
                        if (state.method_28498(CraftingPadBlock.UsedTimes)) {
                            world.method_8501(bpos, state.method_11657(CraftingPadBlock.UsedTimes, used_times));
                        }
                    }
                }
                // Update the result
                CP_ScreenHandler.this.updateCraftingResult();
            }
        });

        // Add player inventory slots
        addPlayerHotbar(playerInventory);
        addPlayerInventory(playerInventory);
    }

    private void addPlayerHotbar(class_1661 playerInventory) {
        for (int i = 0; i < 9; i++) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }

    private void addPlayerInventory(class_1661 playerInventory) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(invSlot);
        if (slot != null && slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();

            if (invSlot == 9) { // Result slot
                if (!this.method_7616(originalStack, 10, 46, true)) {
                    return class_1799.field_8037;
                }
                slot.method_7667(player, originalStack);
            } else if (invSlot < 9) { // Crafting grid slots
                if (!this.method_7616(originalStack, 10, 46, false)) {
                    return class_1799.field_8037;
                }
            } else { // Player inventory slots (10-45)
                if (!this.method_7616(originalStack, 0, 9, false)) {
                    return class_1799.field_8037;
                }
            }

            if (originalStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (originalStack.method_7947() == newStack.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(player, originalStack);
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    @Override
    public void method_7609(class_1263 inventory) {
        if (!this.world.field_9236) {
            updateCraftingResult();
        }
    }

    private void updateCraftingResult() {
        class_1863 recipeManager = world.method_8433();
        // Get all available recipes
        Collection<class_8786<?>> recipes = recipeManager.method_59822();

        for (class_8786<?> entry : recipes) {
            // Check if the recipe is a CraftingRecipe
            if (entry.comp_1933() instanceof class_3955 recipe) {
                // Check if the recipe matches the current crafting inventory
                if (recipe.method_8115(craftingInventory.method_59961(), world)) {
                    // Craft the item and set it as the result
                    class_1799 result = recipe.method_8116(craftingInventory.method_59961(), world.method_30349());
                    this.resultInventory.method_5447(0, result);
                    return; // Exit after finding the first match
                }
            }
        }

        // If no match is found, set the result to empty
        this.resultInventory.method_5447(0, class_1799.field_8037);
    }
}
