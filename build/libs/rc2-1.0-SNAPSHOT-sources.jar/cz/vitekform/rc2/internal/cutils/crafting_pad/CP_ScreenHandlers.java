package cz.vitekform.rc2.internal.cutils.crafting_pad;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

public class CP_ScreenHandlers {
    public static final class_3917<CP_ScreenHandler> PEBBLE_CRAFTING_SCREEN_HANDLER;

    static {
        PEBBLE_CRAFTING_SCREEN_HANDLER = class_2378.method_10230(
                class_7923.field_41187,
                class_2960.method_60655("rc2", "crafting_pad_menu"),
                new class_3917<>(CP_ScreenHandler::new, class_7701.field_40182)
        );
    }

    public static void registerScreenHandlers() {
        // Registration is handled in static initializer
    }
}