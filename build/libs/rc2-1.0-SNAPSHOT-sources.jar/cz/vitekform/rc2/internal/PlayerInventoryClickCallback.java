package cz.vitekform.rc2.internal;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_5536;

public interface PlayerInventoryClickCallback {
    Event<PlayerInventoryClickCallback> EVENT = EventFactory.createArrayBacked(
            PlayerInventoryClickCallback.class,
            (listeners) -> (player, clickType, slot, stack, cursorStack, screenHandler) -> {
                for (PlayerInventoryClickCallback listener : listeners) {
                    class_1269 result = listener.interact(player, clickType, slot, stack, cursorStack, screenHandler);
                    if (result != class_1269.field_5811) {
                        return result;
                    }
                }
                return class_1269.field_5811;
            }
    );

    class_1269 interact(class_1657 player, class_5536 clickType, class_1735 slot, class_1799 stack, class_1799 cursorStack, class_1703 screenHandler);
}