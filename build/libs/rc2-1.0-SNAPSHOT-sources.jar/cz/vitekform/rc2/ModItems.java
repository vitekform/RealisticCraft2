package cz.vitekform.rc2;

import cz.vitekform.rc2.internal.RCItemEnergyStorage;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.logging.Logger;

public class ModItems {
    public static class_1792 register(class_1792 item, class_5321<class_1792> registryKey) {
        // Register the item.
        class_1792 registeredItem = class_2378.method_10230(class_7923.field_41178, registryKey.method_29177(), item);

        // Return the registered item!
        class_1799 stack = new class_1799(registeredItem);
        return registeredItem;
    }

    public static void processItemTags(class_1799 stack) {
        if (stack != null) {
            if (!stack.method_7960()) {
                if (!stack.method_57826(ModComponents.TOTAL_ITEM_ENERGY_COMPONENT)) {
                    double nVal = RCItemEnergyStorage.getRaw(stack);
                    stack.method_57379(ModComponents.TOTAL_ITEM_ENERGY_COMPONENT, nVal);
                }
                if (!stack.method_57826(ModComponents.TOTAL_BURNABLE_CHEMICAL_ENERGY_COMPONENT)) {
                    double nVal = RCItemEnergyStorage.getBurnableChemical(stack);
                    stack.method_57379(ModComponents.TOTAL_BURNABLE_CHEMICAL_ENERGY_COMPONENT, nVal);
                }
                if (!stack.method_57826(ModComponents.REQUIRED_ENERGY_FOR_REFINE_COMPONENT)) {
                    double nVal = RCItemEnergyStorage.getRefine(stack);
                    stack.method_57379(ModComponents.REQUIRED_ENERGY_FOR_REFINE_COMPONENT, nVal);
                }
            }
        }
    }

    private static final String MOD_ID = "rc2";

    public static final class_5321<class_1792> WOOD_BARK_KEY = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "wood_bark"));
    public static final class_1792 WOOD_BARK = register(
            new class_1792(new class_1792.class_1793()),
            WOOD_BARK_KEY
    );

    public static final class_5321<class_1792> ROCK = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "rock"));
    public static final class_1792 ROCK_ITEM = register(
            new class_1792(new class_1792.class_1793()),
            ROCK
    );

    public static final class_5321<class_1792> SHARP_ROCK = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, "sharp_rock"));
    public static final class_1792 SHARP_ROCK_ITEM = register(
            new class_1792(new class_1792.class_1793()),
            SHARP_ROCK
    );

    public static void initialize() {
        FuelRegistry.INSTANCE.add(ModItems.WOOD_BARK, 40);
    }
}
