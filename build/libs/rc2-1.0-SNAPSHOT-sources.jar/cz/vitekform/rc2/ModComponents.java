package cz.vitekform.rc2;

import com.mojang.serialization.Codec;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class ModComponents {
    public static class_9331<Double> TOTAL_ITEM_ENERGY_COMPONENT;
    public static class_9331<Double> TOTAL_BURNABLE_CHEMICAL_ENERGY_COMPONENT;
    public static class_9331<Double> REQUIRED_ENERGY_FOR_REFINE_COMPONENT;
    public static class_9331<Integer> CRAFT_PAD_USED_TIMES_COMPONENT;
    public static class_9331<Double> VOLTAGE_COMPONENT;
    public static class_9331<Double> AMPERAGE_COMPONENT;
    public static class_9331<Double> POWER_STORED_COMPONENT;

    public static void initialize() {
        TOTAL_ITEM_ENERGY_COMPONENT = class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Rc2.MOD_ID, "total_energy_item"),
                class_9331.<Double>method_57873().method_57881(Codec.DOUBLE).method_57880()
        );

        TOTAL_BURNABLE_CHEMICAL_ENERGY_COMPONENT = class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Rc2.MOD_ID, "total_burnable_chemical_energy"),
                class_9331.<Double>method_57873().method_57881(Codec.DOUBLE).method_57880()
        );

        REQUIRED_ENERGY_FOR_REFINE_COMPONENT = class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Rc2.MOD_ID, "required_energy_for_refine"),
                class_9331.<Double>method_57873().method_57881(Codec.DOUBLE).method_57880()
        );

        CRAFT_PAD_USED_TIMES_COMPONENT = class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Rc2.MOD_ID, "craft_pad_used_times"),
                class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57880()
        );

        VOLTAGE_COMPONENT = class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Rc2.MOD_ID, "voltage"),
                class_9331.<Double>method_57873().method_57881(Codec.DOUBLE).method_57880()
        );

        AMPERAGE_COMPONENT = class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Rc2.MOD_ID, "amperage"),
                class_9331.<Double>method_57873().method_57881(Codec.DOUBLE).method_57880()
        );

        POWER_STORED_COMPONENT = class_2378.method_10230(
                class_7923.field_49658,
                class_2960.method_60655(Rc2.MOD_ID, "power_stored"),
                class_9331.<Double>method_57873().method_57881(Codec.DOUBLE).method_57880()
        );
    }
}